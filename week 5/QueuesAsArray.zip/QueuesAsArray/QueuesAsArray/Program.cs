﻿using System;
namespace QueuesAsAnArray
{
    class Program
    {
        static void Main(string [] args)
        {
            Queue queue = new Queue();

            string item;

            for (int index = 1; index <= queue.size(); index++)
            {
                Console.Write("Element" + Convert.ToString(index) + " has been added to queue");
                Console.WriteLine();
                queue.addQ("Element" + Convert.ToString(index));
            }

            Console.WriteLine();
            Console.WriteLine("The front of queue is " + queue.getFront());
            Console.WriteLine();
            Console.WriteLine("The rear of queue is " + queue.getRear());

            queue.deleteQ(out item);
            Console.WriteLine(item + " has been removed from queue");
            queue.deleteQ(out item);
            Console.WriteLine(item + " has been removed from queue");

            queue.displayQ();
        }
    }
}
