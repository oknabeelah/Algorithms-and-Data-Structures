﻿using System;
namespace QueuesUsingtheQueueClass
{
    class program
    {
        
        static void Main(string[] args)
        {
            Queue<string> queue = new Queue<string>();

            string item;
            const int max = 5;

            void displayQ()
            {
                foreach (Object obj in queue)
                {
                    Console.WriteLine(obj.ToString());
                }

            }

            for (int index = 1; index <= max; index++)
            {
                Console.Write("Element" + Convert.ToString(index) + "has been added to queue");
                Console.WriteLine();
                queue.Enqueue("Element" + Convert.ToString(index));
            }
            Console.WriteLine();
            Console.WriteLine("The front of queue is " + queue.First());
            Console.WriteLine("The rear of queue is  " + queue.Last());

            item = queue.First();
            Console.WriteLine(item + " has been removed from queue");
            queue.Dequeue();
            item = queue.First();
            Console.WriteLine(item + " has been removed from queue");
            queue.Dequeue();

            displayQ();

        }

        

    }
}