﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueuesAsAnArray
{
    internal class Queue
    {
        private int front;
        private int rear;
        private const int max = 5;

        private string [] queue = new string[max]; //define a queue that contains up to 5 string values
        public Queue()
        {
            front = -1;
            rear = -1;
        }

        private void shiftToFront()
        {
            for (int index = 1; index <= max - 1; index++)
            {
                queue[index - 1] = queue[index];
            }
            front = - 1;
            rear = rear - 1;
        }

        public void displayQ()
        {
            string item;
            int newFront = front;
            int newRear = rear;

            Console.WriteLine("Queue Contents");
            Console.WriteLine("");
            while (!(newFront == newRear))
            {
                newFront = newFront + 1;
                item = queue[newFront];
                Console.WriteLine(queue[newFront]);
            }

        }
        public void addQ(string item)
        {
            rear = rear + 1;
            queue[rear] = item;
        }

        public void deleteQ(out string item)
        {
            front = front + 1;
            item = queue[front];
            shiftToFront();
        }

        public string getFront()
        {
            return queue[front + 1];
        }

        public string getRear()
        {
            return queue[rear];
        }

        public Boolean isEmpty()
        {
            return (front == rear);
        }

        public Boolean isFull()
        {
            return (rear == max);
        }

        public int size()
        {
            return max;
        }
    }
}
